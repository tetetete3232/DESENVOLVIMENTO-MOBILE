package br.unisanta.appalunodao.view

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.unisanta.appalunodao.R
import br.unisanta.appalunodao.dao.AlunoDao
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AlunoActivity : AppCompatActivity(R.layout.activity_aluno) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val txvNomeAluno = findViewById<TextView>(R.id.txv_nome_aluno)
        val txvTurmaAluno = findViewById<TextView>(R.id.txv_turma_aluno)
        val fabVoltaTelaCadastro = findViewById<FloatingActionButton>(R.id.fab_volta_tela_cadastro)
        val aluno = AlunoDao.buscar()
        txvNomeAluno.setText("Nome: ${aluno?.nome}")
        txvTurmaAluno.setText("Turma: ${aluno?.turma}")

        fabVoltaTelaCadastro.setOnClickListener {
            finish()
        }
    }
}